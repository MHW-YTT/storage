# 铁锅炖服务器包 by 绿林Greenwoo
## 为人民服务！
### [点击下载最新版本（Github）](https://storage.ytt0.top/AUMorePrivateServer/MorePrivateServer.zip)
### [点击下载最新版本（国内）](https://1816541419.v.123pan.cn/1816541419/link/NoS/MorePrivateServers.zip)